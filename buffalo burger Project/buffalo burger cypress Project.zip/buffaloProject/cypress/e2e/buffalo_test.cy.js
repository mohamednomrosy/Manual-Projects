describe('Login Page with incorrect phone number & incorrect password', () => {
  beforeEach(() => {
    cy.on('uncaught:exception', (err) => {
      if (err.message.includes('Unexpected token')) {
        return false;
      }
      return true;
    });
  });
  it('should display an error message for incorrect phone number and password', () => {
    cy.visit("https://buffaloburger.com/branches/all/home");

    // Login
    cy.get('div.font-main.text-lg.font-bold.text-white.hover\\:text-primary-main.flex.justify-center.cursor-pointer')
      .contains('Login')
      .click();
      cy.get('[name="mobile_number"]').type('01118712584');
      cy.get('[name="password"]').type('gskgkaslaal');
      cy.get('[type="submit"]').click();
    
// Verify the error message is displayed
cy.contains('div', 'Mobile number not found').should('be.visible');
    cy.wait(3000); // Wait 3 second before entering address details

  });
});
describe('Login Page with correct phone number & incorrect password', () => {
  beforeEach(() => {
    cy.on('uncaught:exception', (err) => {
      if (err.message.includes('Unexpected token')) {
        return false;
      }
      return true;
    });
  });
  it('should display message an error for correct phone number but incorrect password', () => {
    cy.visit("https://buffaloburger.com/branches/all/home");

    // Login
    cy.get('div.font-main.text-lg.font-bold.text-white.hover\\:text-primary-main.flex.justify-center.cursor-pointer')
      .contains('Login')
      .click();
    
// Enter a correct phone number and an incorrect password
cy.get('[name="mobile_number"]').type('01118712681');
    cy.get('[name="password"]').type('gskgkaslaal');
    cy.get('[type="submit"]').click();
    
// Verify the error message is displayed
cy.contains('div', 'Wrong password').should('be.visible');
    cy.wait(3000); // Wait 3 second before entering address details
  });
});
describe('Login Page with incorrect phone number & correct password', () => {
  beforeEach(() => {
    cy.on('uncaught:exception', (err) => {
      if (err.message.includes('Unexpected token')) {
        return false;
      }
      return true;
    });
  });
  it('should display an erro message for incorrect phone number but correct password', () => {
    cy.visit("https://buffaloburger.com/branches/all/home");

    // Login
    cy.get('div.font-main.text-lg.font-bold.text-white.hover\\:text-primary-main.flex.justify-center.cursor-pointer')
      .contains('Login')
      .click();
    
// Enter an incorrect phone number and the correct password
    cy.get('[name="mobile_number"]').type('01118712684');
    cy.get('[name="password"]').type('Mohamed@123');
    cy.get('[type="submit"]').click();
    
// Verify the error message is displayed
cy.contains('div', 'Mobile number not found').should('be.visible');
    cy.wait(3000); // Wait 3 second before entering address details
  });
});

describe("Login Page with correct phone number & password", () => {
  
  beforeEach(() => {
    // Handle uncaught exceptions
    cy.on('uncaught:exception', (err) => {
      if (err.message.includes('Unexpected token')) {
        return false;
      }
      return true;
    });
  });

  it('should login successfully', () => {
    cy.visit("https://buffaloburger.com/branches/all/home");

    cy.get('div.font-main.text-lg.font-bold.text-white.hover\\:text-primary-main.flex.justify-center.cursor-pointer')
      .contains('Login')
      .click();
    
    cy.get('[name="mobile_number"]').type('01118712681');
    cy.get('[name="password"]').type('Mohamed@123');
    cy.get('[type="submit"]').click();
    
    cy.url().should('include', '/home'); // Adjust URL or condition as needed

    cy.wait(5000); // Wait 5 second before entering address details
    cy.screenshot('post_login');
  });
});

describe("Login with Select 2 sandwiches & meal Offer from offers button", () => {
  beforeEach(() => {
    cy.on('uncaught:exception', (err) => {
      if (err.message.includes('Unexpected token')) {
        return false;
      }
      return true;
    });
  });

  it('Selects items from offers and performs checkout', () => {
    cy.visit("https://buffaloburger.com/branches/all/home");

    // Login
    cy.get('div.font-main.text-lg.font-bold.text-white.hover\\:text-primary-main.flex.justify-center.cursor-pointer')
      .contains('Login')
      .click();
    
    cy.get('[name="mobile_number"]').type('01118712681');
    cy.get('[name="password"]').type('Mohamed@123');
    cy.get('[type="submit"]').click();
    
    cy.wait(4000); // Wait 4 second before selecting time
    // Take a screenshot after logging in
    cy.screenshot('offers_page_after_login');
    
    // Wait for offers button to be visible and clickable
    cy.get('img[alt="offers"]').should('be.visible').click();
    
    // Select and add first item to cart
    cy.get('img[alt="Buffalo burger - menu item Shiitake Mushroom image"]').click();
    cy.contains('button', 'Add to cart').click();
    
    // Wait for city selection to be interactive
    cy.contains('div', 'Select city').should('be.visible').click();
    cy.contains('div', 'Giza').should('be.visible').click();
    
    cy.contains('div', 'Select area').should('be.visible').click();
    cy.contains('div', 'Sixth of October').should('be.visible').click();
    
    cy.contains('div', 'Select branch').should('be.visible').click();
    cy.contains('div', 'West Somid').should('be.visible').dblclick();
    cy.screenshot('branch_selected');
    
    cy.contains('button', 'Start ordering').should('be.visible').click();

    // Add second item to cart and navigate back
    cy.contains('button', 'Add to cart').click();
    cy.get('div.flex.justify-center.font-main.text-lg.font-bold.hover\\:text-primary-main.uppercase.text-white.cursor-pointer')
  .contains('Cart')
  .click();
  cy.screenshot('first_item_added_to_cart');
    cy.go('back');
    cy.go('back');
    cy.go('back');

    // Select and add second item to cart
    cy.get('img[alt="Buffalo burger - menu item Old School image"]').click();
    cy.contains('button', 'Add to cart').click();
    cy.get('div.flex.justify-center.font-main.text-lg.font-bold.hover\\:text-primary-main.uppercase.text-white.cursor-pointer')
    .contains('Cart')
    .click();
    cy.wait(4000); // Wait 4 second before selecting time
    cy.screenshot('second_item_added_to_cart');
      cy.go('back');
      cy.go('back');
      cy.go('back');

    
    // Select and add offer to cart
    cy.get('img[alt="Buffalo Burger - offer Buff Three image"]').click();
    cy.contains('p', 'Pickled sliced jalapeños, Buffalo sauce and cheddar cheese on top of our pure..')
      .should('be.visible')
      .click();
    
    cy.contains('button', 'Next').should('be.visible').click();
    cy.contains('p', 'Grilled burger topped with sweet onion, BBQ sauce, creamy Charbroiled sauce, and Swiss.. (EGP 15.00)')
      .should('be.visible')
      .click();
    
    cy.contains('button', 'Next').should('be.visible').click();
    cy.contains('p', 'Chicken strips with pickled sliced jalapeños, Buffalo sauce, and melted cheddar cheese. (EGP 15.00)')
      .should('be.visible')
      .click();
    
    cy.contains('button', 'Next').should('be.visible').click();
    cy.contains('button', 'Next').should('be.visible').click(); // Repeat for remaining steps if needed

    cy.contains('button', 'Add to cart').should('be.visible').click();
    cy.get('div.flex.justify-center.font-main.text-lg.font-bold.hover\\:text-primary-main.uppercase.text-white.cursor-pointer')
    .contains('Cart')
    .click();
    cy.wait(4000); // Wait 4 seconds before selecting time
    cy.screenshot('meal_added_to_cart');
      cy.go('back');
      cy.go('back');
      cy.go('back');
    // Proceed to checkout
    cy.get('div.flex.justify-center.font-main.text-lg.font-bold.hover\\:text-primary-main.uppercase.text-white.cursor-pointer').click();
    cy.contains('button', 'Checkout').should('be.visible').click();

    // Fill in address details
    cy.wait(1000); // Wait 1 second before entering address details
    cy.get('[name="second_mobile_number"]').type('01118712681');
    cy.screenshot('checkout_page');

    cy.get('div.css-19bb58m').click();
    cy.contains('div', 'Sixth of October').should('be.visible').click();

    cy.get('div.css-1jtu45f-control').click();
    cy.contains('div', 'Al shaykh Zayed Services Region').should('be.visible').click();

    cy.get('[name="address_details.building_number"]').type('16');
    cy.get('[name="address_details.floor_number"]').type('4');
    cy.get('[name="address_details.appartment_number"]').type('122');
    cy.get('[name="address_details.extra_details"]').type('Thank You');

    // Choose delivery time
    cy.contains('span', 'Order Later').click();
    cy.get('div.css-m2a98b-control').click();
    cy.contains('div', 'Today').should('be.visible').click();
    cy.get('div.css-m2a98b-control').click({ force: true }); // Ensure dropdown interaction
    cy.screenshot('delivery_time_selected');
  });
});
